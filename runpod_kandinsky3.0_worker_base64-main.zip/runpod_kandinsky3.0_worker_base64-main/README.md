# Kadinsky 3.0 worker
